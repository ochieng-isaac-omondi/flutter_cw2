package com.example.login_screen

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
